<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => '您訪問的頁面出去玩了!',
    'The page does not exist, please click the link at the bottom of the page to return' => '您訪問的頁面不存在，請點擊頁底的鏈接返回',
    'Access error' => '訪問出錯',
    'Return to the home page' => '返回首頁'
];