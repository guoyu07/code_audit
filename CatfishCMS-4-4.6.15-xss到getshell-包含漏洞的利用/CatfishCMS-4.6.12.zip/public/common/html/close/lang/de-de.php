<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => 'Website braucht eine Pause!',
    'In the system maintenance, please come again tomorrow' => 'Systemwartung , bitte komm zurück morgen',
    'Temporarily closed' => 'Vorübergehend geschlossen'
];