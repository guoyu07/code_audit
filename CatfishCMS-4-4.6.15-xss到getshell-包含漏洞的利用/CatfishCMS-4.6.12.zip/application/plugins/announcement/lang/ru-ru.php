<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => 'Объявление',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => 'Объявление плагин для отображения уведомления в верхней части главной страницы',
    'Notice content' => 'Содержание уведомления',
    'Save' => 'Сохранить'
];