<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => '公告',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => 'ホームページの最上には公告が表示されます',
    'Notice content' => '公告の内容',
    'Save' => '保存'
];