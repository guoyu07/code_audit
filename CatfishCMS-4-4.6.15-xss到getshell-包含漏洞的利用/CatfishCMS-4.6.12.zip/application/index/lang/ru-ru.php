<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/28
 */
return [
    'Article list' => 'список статей',
    'No search found' => 'не  найти  поиска контента',
    'Search' => 'поиск',
    'Message content must be filled out' => 'содержание сообщений,  должны заполнить',
    'The e-mail format is incorrect' => 'Формат электронной почты неверен'
];