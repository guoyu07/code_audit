<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/30
 */
return [
    'Article list' => '기사 목록',
    'No search found' => '검색 내용을 찾을 수 없습니다',
    'Search' => '검색',
    'Message content must be filled out' => '댓글 작성 내용은 반드시',
    'The e-mail format is incorrect' => '전자 메일 형식이 잘못되었습니다.'
];