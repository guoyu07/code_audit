<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/27
 */
return [
    'Article list' => '文章列表',
    'No search found' => '沒有找到搜索內容',
    'Search' => '搜索',
    'Message content must be filled out' => '留言內容必須填寫',
    'The e-mail format is incorrect' => '郵箱格式錯誤'
];