<?php
$photo_markup = '1';
$photo_markdown = '1';
$photo_marktype = '1';
$photo_wwidth = '120';
$photo_wheight = '120';
$photo_waterpos = '9';
$photo_watertext = 'www.dedecms.com';
$photo_fontsize = '20';
$photo_fontcolor = '0,0,0';
$photo_marktrans = '100';
$photo_diaphaneity = '100';
$photo_markimg = 'mark.png';
?>
